package edu.pe.vallegrande.maestro2.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.pe.vallegrande.maestro2.db.service.imple.CrudProductService;
import edu.pe.vallegrande.maestro2.db.service.imple.CrudSupplierService;
import edu.pe.vallegrande.maestro2.model.product;
import edu.pe.vallegrande.maestro2.model.supplier;

@WebServlet({ "/SearchProduct", "/SearchSupplier", "/SearchInactivos"})
public class SearchController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		switch (path) {
		case "/SearchProduct":
			searchProduct(request, response);
			break;
		case "/SearchSupplier":
			searchSupplier(request, response);
			break;
		case "/SearchInactivos":
			searchInactivos(request, response);
			break;
		}
	}

	private void searchInactivos(HttpServletRequest request, HttpServletResponse response) {
		try {
	        // Obtén los parámetros de búsqueda del formulario
	        String brand = request.getParameter("brand");
	        String descripcion = request.getParameter("descripcion");

	        // Crea un objeto Product con los parámetros de búsqueda
	        product bean = new product();
	        bean.setBrand(brand);
	        bean.setDescripcion(descripcion);

	        // Llama al servicio para obtener los productos que coinciden con los parámetros de búsqueda
	        CrudProductService productService = new CrudProductService();
	        List<product> lista = productService.getInactiveProducts(bean);

	        // Establece la lista de productos como un atributo en la solicitud
	        request.setAttribute("productos", lista);

	        // Redirige a la página JSP para mostrar los resultados
	        request.getRequestDispatcher("Inactivos.jsp").forward(request, response);
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}

	private void searchSupplier(HttpServletRequest request, HttpServletResponse response) {
		try {

			String business_name = request.getParameter("business_name");
			String addres = request.getParameter("addres");

			supplier bean = new supplier();
			bean.setBusiness_name(business_name);
			bean.setAddres(addres);

			CrudSupplierService supplierService = new CrudSupplierService();
			List<supplier> lista = supplierService.get(bean);

			request.setAttribute("proveedores", lista);

			request.getRequestDispatcher("crudProveedor.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void searchProduct(HttpServletRequest request, HttpServletResponse response) {
		try {

			String brand = request.getParameter("brand");
			String descripcion = request.getParameter("descripcion");

			product bean = new product();
			bean.setBrand(brand);
			bean.setDescripcion(descripcion);

			CrudProductService productService = new CrudProductService();
			List<product> lista = productService.get(bean);

			request.setAttribute("productos", lista);

			request.getRequestDispatcher("crudProducto.jsp").forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
