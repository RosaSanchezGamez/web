package edu.pe.vallegrande.maestro2.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.pe.vallegrande.maestro2.db.service.imple.CrudProductService;
import edu.pe.vallegrande.maestro2.db.service.imple.CrudSupplierService;
import edu.pe.vallegrande.maestro2.model.product;
import edu.pe.vallegrande.maestro2.model.supplier;

@WebServlet({ "/Listar", "/ListSupplier", "/ListInactivos", "/ListInactivosProveedor"})
public class ListarController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		switch (path) {
		case "/Listar":
			listar(request, response);
			break;
		case "/ListSupplier":
			listSupplier(request, response);
			break;
		case "/ListInactivos":
			listInactivos(request, response);
			break;	
		case "/ListInactivosProveedor":
			listInactivosProveedor(request, response);
			break;

		}
	}

	private void listInactivos(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Variables
	    String destino;

	    // Proceso de listado de productos inactivos
	    CrudProductService productService = new CrudProductService();
	    List<product> productos = productService.getInactiveProducts();

	    // Establece la lista de productos inactivos como un atributo en la solicitud
	    request.setAttribute("productos", productos);

	    // Aquí puedes definir la página JSP de destino (por ejemplo, "productosInactivos.jsp")
	    destino = "Inactivos.jsp";

	    // Redirección a la página JSP de destino
	    RequestDispatcher rd = request.getRequestDispatcher(destino);
	    rd.forward(request, response);
	}
	
	private void listInactivosProveedor(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Variables
	    String destino;

	    // Proceso de listado de productos inactivos
	    CrudSupplierService supplierService = new CrudSupplierService();
	    List<supplier> supplier = supplierService.getInactiveProveedor();

	    // Establece la lista de productos inactivos como un atributo en la solicitud
	    request.setAttribute("proveedor", supplier);

	    // Aquí puedes definir la página JSP de destino (por ejemplo, "productosInactivos.jsp")
	    destino = "InactivosProveedor.jsp";

	    // Redirección a la página JSP de destino
	    RequestDispatcher rd = request.getRequestDispatcher(destino);
	    rd.forward(request, response);
	}

	
	private void listSupplier(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Variables
		String destino;

		// Proceso de listado
		CrudSupplierService service = new CrudSupplierService();
		List<supplier> proveedores = service.getAll();

		// Establece la lista de productos como un atributo en la solicitud
		request.setAttribute("proveedores", proveedores);

		// Aquí puedes definir la página JSP de destino
		destino = "crudProveedor.jsp";

		// Redirección a la página JSP de destino
		RequestDispatcher rd = request.getRequestDispatcher(destino);
		rd.forward(request, response);

	}

	private void listar(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Variables
		String destino;

		// Proceso de listado
		CrudProductService service = new CrudProductService();
		List<product> productos = service.getAll();

		// Establece la lista de productos como un atributo en la solicitud
		request.setAttribute("productos", productos);

		// Aquí puedes definir la página JSP de destino
		destino = "crudProducto.jsp";

		// Redirección a la página JSP de destino
		RequestDispatcher rd = request.getRequestDispatcher(destino);
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
