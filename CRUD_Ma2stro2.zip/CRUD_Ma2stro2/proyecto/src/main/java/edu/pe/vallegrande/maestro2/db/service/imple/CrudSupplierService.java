package edu.pe.vallegrande.maestro2.db.service.imple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;

import edu.pe.vallegrande.maestro2.db.AccesoDB;
import edu.pe.vallegrande.maestro2.db.service.spec.CrudServiceSpec;
import edu.pe.vallegrande.maestro2.model.product;
import edu.pe.vallegrande.maestro2.model.supplier;

public class CrudSupplierService implements CrudServiceSpec<supplier> {

	@Override
	public List<supplier> getAll() {
		List<supplier> lista = new ArrayList<>();
		Connection cn = null;
		supplier rec = null;
		try {
			cn = AccesoDB.getConnection();
			String sql = "select id_supplier, ruc, business_name, addres, email, phone, active from supplier where active = 'A'";
			PreparedStatement pstm = cn.prepareStatement(sql);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				rec = new supplier();
				rec.setId_supplier(rs.getInt("id_supplier"));
				rec.setRuc(rs.getString("ruc"));
				rec.setBusiness_name(rs.getString("business_name"));
				rec.setAddres(rs.getString("addres"));
				rec.setEmail(rs.getString("email"));
				rec.setPhone(rs.getString("phone"));
				rec.setActive(rs.getString("active").charAt(0));
				lista.add(rec);
			}
			rs.close();
			pstm.close();
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				cn.close();
			} catch (Exception e) {
			}
		}
		return lista;
	}

	@Override
	public List<supplier> get(supplier bean) {
		// Preparando datos
		String business_name = "%" + bean.getBusiness_name().trim() + "%";
		String addres = "%" + bean.getAddres().trim() + "%";
		List<supplier> lista = new ArrayList<>();
		Connection cn = null;
		supplier rec = null;
		// Proceso
		try {
			cn = AccesoDB.getConnection();
			String sql = "select id_supplier, ruc, business_name, addres, email, phone from supplier ";
			sql += "where business_name like ? and addres like ?";
			PreparedStatement pstm = cn.prepareStatement(sql);
			pstm.setString(1, business_name);
			pstm.setString(2, addres);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				rec = new supplier();
				rec.setId_supplier(rs.getInt("id_supplier"));
				rec.setRuc(rs.getString("ruc"));
				rec.setBusiness_name(rs.getString("Business_name"));
				rec.setAddres(rs.getString("addres"));
				rec.setEmail(rs.getString("email"));
				rec.setPhone(rs.getString("phone"));
				lista.add(rec);
			}
			rs.close();
			pstm.close();
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				cn.close();
			} catch (Exception e) {
			}
		}
		return lista;
	}

	@Override
	public supplier insert(supplier bean) {
		// Variables
		Integer id;
		Connection cn = null;
		PreparedStatement pstm;
		ResultSet rs;
		String sql;
		// Proceso
		try {
			// Inicio de la TX
			cn = AccesoDB.getConnection();
			cn.setAutoCommit(false);
			// Insertar registro
			sql = "INSERT INTO supplier(ruc, business_name, addres, email, phone) VALUES(?,?,?,?,?)";
			pstm = cn.prepareStatement(sql);
			pstm.setString(1, bean.getRuc());
			pstm.setString(2, bean.getBusiness_name());
			pstm.setString(3, bean.getAddres());
			pstm.setString(4, bean.getEmail());
			pstm.setString(5, bean.getPhone());
			pstm.executeUpdate();
			// Obteniendo el id
			sql = "SELECT @@IDENTITY id_supplier";
			pstm = cn.prepareStatement(sql);
			rs = pstm.executeQuery();
			rs.next();
			id = rs.getInt("id_supplier");
			bean.setId_supplier(id);
			// Fin de la TX
			cn.commit();
		} catch (SQLException e) {
			try {
				cn.rollback();
			} catch (Exception e2) {
			}
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			try {
				cn.rollback();
			} catch (Exception e2) {
			}
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				cn.close();
			} catch (Exception e) {
			}
		}

		// Reporte
		bean.setId_supplier(id);
		return bean;
	}

	@Override
	public supplier read(Integer id) {
		supplier supplier = null;

		Connection cn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = AccesoDB.getConnection();

			sql = "SELECT id_supplier, ruc, business_name, addres, email, phone FROM supplier WHERE id_supplier = ?";
			pstm = cn.prepareStatement(sql);
			pstm.setInt(1, id);

			rs = pstm.executeQuery();

			if (rs.next()) {
				supplier = new supplier();
				supplier.setId_supplier(rs.getInt("id_supplier"));
				supplier.setRuc(rs.getString("ruc"));
				supplier.setBusiness_name(rs.getString("business_name"));
				supplier.setAddres(rs.getString("addres"));
				supplier.setEmail(rs.getString("email"));
				supplier.setPhone(rs.getString("phone"));
			}
		} catch (SQLException e) {
			throw new RuntimeException("Error al leer el proveedor: " + e.getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (cn != null)
					cn.close();
			} catch (Exception e) {
			}
		}
		return supplier;
	}

	@Override
	public supplier update(supplier bean) {
		Connection cn = null;
		PreparedStatement pstm = null;
		String sql = "UPDATE supplier SET ruc=?, business_name=?, addres=?, email=?, phone=? WHERE id_supplier=?";

		try {
			cn = AccesoDB.getConnection();
			pstm = cn.prepareStatement(sql);
			pstm.setString(1, bean.getRuc());
			pstm.setString(2, bean.getBusiness_name());
			pstm.setString(3, bean.getAddres());
			pstm.setString(4, bean.getEmail());
			pstm.setString(5, bean.getPhone());
			pstm.setInt(6, bean.getId_supplier());

			int rowsUpdated = pstm.executeUpdate();

			if (rowsUpdated != 1) {
				throw new RuntimeException("No se pudo actualizar el proveedor.");
			}

			return bean;
		} catch (SQLException e) {
			throw new RuntimeException("Error al actualizar el proveedor: " + e.getMessage());
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (cn != null) {
					cn.close();
				}
			} catch (Exception e) {
				// Manejar la excepción o registrarla
			}
		}
	}
	
	@Override
	public void delete(Integer id) {
	    // Variables
	    Connection cn = null;
	    PreparedStatement pstm = null;
	    String sql;

	    try {
	        cn = AccesoDB.getConnection();
	        cn.setAutoCommit(false);

	        sql = "UPDATE supplier SET active = 'I' WHERE id_supplier = ?";
	        pstm = cn.prepareStatement(sql);
	        pstm.setInt(1, id);

	        int rowsDeleted = pstm.executeUpdate();

	        if (rowsDeleted != 1) {
	            throw new RuntimeException("No se pudo realizar la eliminación física del proveedor.");
	        }

	        // Fin de la TX
	        cn.commit();
	    } catch (SQLException e) {
	        try {
	            cn.rollback();
	        } catch (Exception e2) {
	        }
	        throw new RuntimeException("Error al realizar la eliminación física del proveedor: " + e.getMessage());
	    } catch (Exception e) {
	        try {
	            cn.rollback();
	        } catch (Exception e2) {
	        }
	        throw new RuntimeException("Error en el proceso");
	    } finally {
	        try {
	            if (pstm != null) {
	                pstm.close();
	            }
	            if (cn != null) {
	                cn.close();
	            }
	        } catch (Exception e) {
	        }
	    }
	}

	@Override
	public List<supplier> getInactiveProveedor(supplier bean) {
		 String businessName = "%" + bean.getBusiness_name()+ "%";
		    String ruc = "%" + bean.getRuc() + "%";
		    List<supplier> lista = new ArrayList<>();
		    Connection cn = null;
		    supplier rec = null;
		    // Proceso
		    try {
		        cn = AccesoDB.getConnection();
		        String sql = "SELECT * FROM supplier ";
		        sql += "WHERE active = 'I'"; // Cambiamos la condición para registros inactivos
		        PreparedStatement pstm = cn.prepareStatement(sql);
		        pstm.setString(1, businessName);
		        pstm.setString(2, ruc);
		        ResultSet rs = pstm.executeQuery();
		        while (rs.next()) {
		            rec = new supplier();
		            rec.setActive(rs.getString("active").charAt(0));
		            lista.add(rec);
		        }
		        rs.close();
		        pstm.close();
		    } catch (SQLException e) {
		        throw new RuntimeException(e.getMessage());
		    } catch (Exception e) {
		        throw new RuntimeException("Error en el proceso");
		    } finally {
		        try {
		            cn.close();
		        } catch (Exception e) {
		        }
		    }
		    return lista;
	}
	
	@Override
	public List<supplier> getInactiveProveedor() {
		List<supplier> lista = new ArrayList<>();
		Connection cn = null;
		supplier rec = null;
		try {
			cn = AccesoDB.getConnection();
			String sql = "select id_supplier, ruc, business_name, addres, email, phone, active from supplier where active = 'I'";
			PreparedStatement pstm = cn.prepareStatement(sql);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				rec = new supplier();
				rec.setId_supplier(rs.getInt("id_supplier"));
				rec.setRuc(rs.getString("ruc"));
				rec.setBusiness_name(rs.getString("business_name"));
				rec.setAddres(rs.getString("addres"));
				rec.setEmail(rs.getString("email"));
				rec.setPhone(rs.getString("phone"));
				rec.setActive(rs.getString("active").charAt(0));
				lista.add(rec);
			}
			rs.close();
			pstm.close();
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				cn.close();
			} catch (Exception e) {
			}
		}
		return lista;
	}

	@Override
	public void restore(Integer id) {
		// Variables
	    Connection cn = null;
	    PreparedStatement pstm = null;
	    String sql;

	    try {
	        // Inicio de la TX
	        cn = AccesoDB.getConnection();
	        cn.setAutoCommit(false);

	        // Realizar la restauración lógica marcando el registro como activo ('A')
	        sql = "UPDATE supplier SET active = 'A' WHERE id_supplier = ?";
	        pstm = cn.prepareStatement(sql);
	        pstm.setInt(1, id);

	        int rowsUpdated = pstm.executeUpdate();

	        if (rowsUpdated != 1) {
	            throw new RuntimeException("No se pudo realizar la restauración lógica del producto.");
	        }

	        // Fin de la TX
	        cn.commit();
	    } catch (SQLException e) {
	        try {
	            cn.rollback();
	        } catch (Exception e2) {
	        }
	        throw new RuntimeException("Error al realizar la restauración lógica del producto: " + e.getMessage());
	    } catch (Exception e) {
	        try {
	            cn.rollback();
	        } catch (Exception e2) {
	        }
	        throw new RuntimeException("Error en el proceso");
	    } finally {
	        try {
	            if (pstm != null) {
	                pstm.close();
	            }
	            if (cn != null) {
	                cn.close();
	            }
	        } catch (Exception e) {
	        }
	    }
		
	}

	@Override
	public String getCSVData() {
		// Lógica para obtener datos en formato CSV
        List<supplier> suppliers = getAll();
        StringBuilder csvData = new StringBuilder();
        csvData.append("ID,Ruc,Nombre,Direccion,Email,Celular\n");        

        for (supplier supplier : suppliers) {
            csvData.append(String.format("%d,%s,%s,%s,%s,%s\n",
            		supplier.getId_supplier(),
            		supplier.getRuc(),
            		supplier.getBusiness_name(),
            		supplier.getAddres(),
            		supplier.getEmail(),
            		supplier.getPhone()));
        }

        return csvData.toString();
    }


	@Override
	public HSSFWorkbook getXLSData() {
	    HSSFWorkbook workbook = new HSSFWorkbook(); // Inicializar el objeto HSSFWorkbook

	    HSSFSheet sheet = workbook.createSheet("Proveedores");

	    // Crear encabezados
	    HSSFRow headerRow = sheet.createRow(0);
	    headerRow.createCell(0).setCellValue("ID");
	    headerRow.createCell(1).setCellValue("Ruc");
	    headerRow.createCell(2).setCellValue("Nombre");
	    headerRow.createCell(3).setCellValue("Direccion");
	    headerRow.createCell(4).setCellValue("Email");
	    headerRow.createCell(5).setCellValue("Celular");
		
	    int rowNum = 1;
	    List<supplier> suppliers = getAll(); // Obtener los productos
	    for (supplier supplier : suppliers) {
	        HSSFRow row = sheet.createRow(rowNum++);
	        row.createCell(0).setCellValue(supplier.getId_supplier());
	        row.createCell(1).setCellValue(supplier.getRuc());
	        row.createCell(2).setCellValue(supplier.getBusiness_name());
	        row.createCell(3).setCellValue(supplier.getAddres());
	        row.createCell(4).setCellValue(supplier.getEmail());
	        row.createCell(5).setCellValue(supplier.getPhone());
	    }

	    return workbook;
	}

	@Override
	public void getPDFData(Document document) throws DocumentException {
	    // Obtener los datos para el informe (puedes usar tu lógica específica)
	    List<supplier> suppliers = getAll();

	    // Puedes personalizar el contenido según tus necesidades
	    for (supplier supplier : suppliers) {
	        // Agregar información del producto al documento
	        document.add(new Paragraph("ID: " + supplier.getId_supplier()));
	        document.add(new Paragraph("Ruc: " + supplier.getRuc()));
	        document.add(new Paragraph("Nombre: " + supplier.getBusiness_name()));
	        document.add(new Paragraph("Direccion: " + supplier.getAddres()));
	        document.add(new Paragraph("Email: " + supplier.getEmail()));
	        document.add(new Paragraph("Celular: " + supplier.getPhone()));
	        document.add(new Paragraph("Estado: " + supplier.getActive()));
	        document.add(new Paragraph("")); // Agregar espacio entre productos
	    }
	}

	@Override
	public List<supplier> getInactiveProducts(supplier bean) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<supplier> getInactiveProducts() {
		// TODO Auto-generated method stub
		return null;
	}

	
}
