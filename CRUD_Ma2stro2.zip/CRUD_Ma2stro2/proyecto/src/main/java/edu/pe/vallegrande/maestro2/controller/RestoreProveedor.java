package edu.pe.vallegrande.maestro2.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.pe.vallegrande.maestro2.db.service.imple.CrudProductService;
import edu.pe.vallegrande.maestro2.db.service.imple.CrudSupplierService;

@WebServlet({ "/RestoreProveedor" })
public class RestoreProveedor extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		   try {
	   
	            int productIdToRestore = Integer.parseInt(request.getParameter("id"));

	            
	            CrudSupplierService service = new CrudSupplierService();
	            service.restore(productIdToRestore);

	            
	            response.sendRedirect("ListSupplier");
	        } catch (Exception e) {
	       
	        }
	    }
	}
