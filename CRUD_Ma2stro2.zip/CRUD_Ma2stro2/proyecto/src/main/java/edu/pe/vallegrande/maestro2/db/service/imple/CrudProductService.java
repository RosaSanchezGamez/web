package edu.pe.vallegrande.maestro2.db.service.imple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;

import edu.pe.vallegrande.maestro2.db.AccesoDB;
import edu.pe.vallegrande.maestro2.db.service.spec.CrudServiceSpec;
import edu.pe.vallegrande.maestro2.model.product;

public class CrudProductService implements CrudServiceSpec<product>{

	@Override
	public List<product> getAll() {
		List<product> lista = new ArrayList<>();
		Connection cn = null;
		product rec = null;
		try {
			cn = AccesoDB.getConnection();
			String sql = "select id_product, brand, descripcion, category, price, stock, active from product where active = 'A'";
			PreparedStatement pstm = cn.prepareStatement(sql);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				rec = new product();
				rec.setId_product(rs.getInt("id_product"));
				rec.setBrand(rs.getString("brand"));
				rec.setDescripcion(rs.getString("descripcion"));
				rec.setCategory(rs.getString("category"));
				rec.setPrice(rs.getDouble("price"));
				rec.setStock(rs.getInt("stock"));
				rec.setActive(rs.getString("active").charAt(0));
				lista.add(rec);
			}
			rs.close();
			pstm.close();
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				cn.close();
			} catch (Exception e) {
			}
		}
		return lista;
	}

	@Override
	public List<product> get(product bean) {
		// Preparando datos
		String brand = "%" + bean.getBrand().trim() + "%";
		String descripcion = "%" + bean.getDescripcion().trim() + "%";
		List<product> lista = new ArrayList<>();
		Connection cn = null;
		product rec = null;
		// Proceso
		try {
			cn = AccesoDB.getConnection();
			String sql = "select id_product, brand, descripcion, category, price, stock, active from product ";
			sql += "where brand like ? and descripcion like ? AND active = 'A'";
			PreparedStatement pstm = cn.prepareStatement(sql);
			pstm.setString(1, brand);
			pstm.setString(2, descripcion);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				rec = new product();
				rec.setId_product(rs.getInt("id_product"));
				rec.setBrand(rs.getString("brand"));
				rec.setDescripcion(rs.getString("descripcion"));
				rec.setCategory(rs.getString("category"));
				rec.setPrice(rs.getDouble("price"));
				rec.setStock(rs.getInt("stock"));
				rec.setActive(rs.getString("active").charAt(0));
				lista.add(rec);
			}
			rs.close();
			pstm.close();
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				cn.close();
			} catch (Exception e) {
			}
		}
		return lista;
	}

	@Override
	public product insert(product bean) {
		// Variables
		Connection cn = null;
		String sql = null;
		PreparedStatement pstm = null;
		ResultSet rs;
		Integer id = 0;
		// Proceso
		try {
			// Inicio de la TX
			cn = AccesoDB.getConnection();
			cn.setAutoCommit(false);
			// Insertar registro
			sql = "INSERT INTO product(brand, descripcion, category, price, stock) VALUES(?,?,?,?,?)";
			pstm = cn.prepareStatement(sql);
			pstm.setString(1, bean.getBrand());
			pstm.setString(2, bean.getDescripcion());
			pstm.setString(3, bean.getCategory());
			pstm.setDouble(4, bean.getPrice());
			pstm.setInt(5, bean.getStock());
			pstm.executeUpdate();
			// Obteniendo el id
			sql = "SELECT @@IDENTITY id_product";
			pstm = cn.prepareStatement(sql);
			rs = pstm.executeQuery();
			rs.next();
			id = rs.getInt("id_product");
			bean.setId_product(id);
			// Fin de la TX
			cn.commit();
		} catch (SQLException e) {
			try {
				cn.rollback();
			} catch (Exception e2) {
			}
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			try {
				cn.rollback();
			} catch (Exception e2) {
			}
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				cn.close();
			} catch (Exception e) {
			}
		}

		// Reporte
		bean.setId_product(id);
		return bean;
	}

	@Override
	public product read(Integer id) {

		product product = null;

		Connection cn = null;
		PreparedStatement pstm = null;
		ResultSet rs = null;
		String sql;

		try {
			cn = AccesoDB.getConnection();

			sql = "SELECT id_product, brand, descripcion, category, price, stock FROM product WHERE id_product = ?";
			pstm = cn.prepareStatement(sql);
			pstm.setInt(1, id);

			rs = pstm.executeQuery();

			if (rs.next()) {
				product = new product();
				product.setId_product(rs.getInt("id_product"));
				product.setBrand(rs.getString("brand"));
				product.setDescripcion(rs.getString("descripcion"));
				product.setCategory(rs.getString("category"));
				product.setPrice(rs.getDouble("price"));
				product.setStock(rs.getInt("stock"));
			}
		} catch (SQLException e) {
			throw new RuntimeException("Error al leer el producto: " + e.getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstm != null)
					pstm.close();
				if (cn != null)
					cn.close();
			} catch (Exception e) {
			}
		}
		return product;
	}

	@Override
	public product update(product bean) {
		Connection cn = null;
		PreparedStatement pstm = null;
		String sql = "UPDATE product SET brand=?, descripcion=?, category=?, price=?, stock=? WHERE id_product=?";

		try {
			cn = AccesoDB.getConnection();
			pstm = cn.prepareStatement(sql);
			pstm.setString(1, bean.getBrand());
			pstm.setString(2, bean.getDescripcion());
			pstm.setString(3, bean.getCategory());
			pstm.setDouble(4, bean.getPrice());
			pstm.setInt(5, bean.getStock());
			pstm.setInt(6, bean.getId_product());

			int rowsUpdated = pstm.executeUpdate();

			if (rowsUpdated != 1) {
				throw new RuntimeException("No se pudo actualizar el producto.");
			}

			return bean;
		} catch (SQLException e) {
			throw new RuntimeException("Error al actualizar el producto: " + e.getMessage());
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (cn != null) {
					cn.close();
				}
			} catch (Exception e) {
				// Manejar la excepción o registrarla
			}
		}
	}

	@Override
	public void delete(Integer id) {
		// Variables
		Connection cn = null;
		PreparedStatement pstm = null;
		String sql;

		try {
			// Inicio de la TX
			cn = AccesoDB.getConnection();
			cn.setAutoCommit(false);

			// Realizar la eliminación lógica marcando el registro como inactivo ('I')
			sql = "UPDATE product SET active = 'I' WHERE id_product = ?";
			pstm = cn.prepareStatement(sql);
			pstm.setInt(1, id);

			int rowsUpdated = pstm.executeUpdate();

			if (rowsUpdated != 1) {
				throw new RuntimeException("No se pudo realizar la eliminación lógica del producto.");
			}

			// Fin de la TX
			cn.commit();
		} catch (SQLException e) {
			try {
				cn.rollback();
			} catch (Exception e2) {
			}
			throw new RuntimeException("Error al realizar la eliminación lógica del producto: " + e.getMessage());
		} catch (Exception e) {
			try {
				cn.rollback();
			} catch (Exception e2) {
			}
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				if (pstm != null) {
					pstm.close();
				}
				if (cn != null) {
					cn.close();
				}
			} catch (Exception e) {
			}
		}
	}

	@Override
	public List<product> getInactiveProducts() {
		List<product> lista = new ArrayList<>();
	    Connection cn = null;
	    product rec = null;
	    try {
	        cn = AccesoDB.getConnection();
	        String sql = "SELECT id_product, brand, descripcion, category, price, stock, active FROM product WHERE active = 'I'";
	        PreparedStatement pstm = cn.prepareStatement(sql);
	        ResultSet rs = pstm.executeQuery();
	        while (rs.next()) {
	            rec = new product();
	            rec.setId_product(rs.getInt("id_product"));
	            rec.setBrand(rs.getString("brand"));
	            rec.setDescripcion(rs.getString("descripcion"));
	            rec.setCategory(rs.getString("category"));
	            rec.setPrice(rs.getDouble("price"));
	            rec.setStock(rs.getInt("stock"));
	            rec.setActive(rs.getString("active").charAt(0));
	            lista.add(rec);
	        }
	        rs.close();
	        pstm.close();
	    } catch (SQLException e) {
	        throw new RuntimeException(e.getMessage());
	    } catch (Exception e) {
	        throw new RuntimeException("Error en el proceso");
	    } finally {
	        try {
	            cn.close();
	        } catch (Exception e) {
	        }
	    }
	    return lista;
	}

	@Override
	public List<product> getInactiveProducts(product bean) {
		// Preparando datos
	    String brand = "%" + bean.getBrand().trim() + "%";
	    String descripcion = "%" + bean.getDescripcion().trim() + "%";
	    List<product> lista = new ArrayList<>();
	    Connection cn = null;
	    product rec = null;
	    // Proceso
	    try {
	        cn = AccesoDB.getConnection();
	        String sql = "SELECT id_product, brand, descripcion, category, price, stock, active FROM product ";
	        sql += "WHERE brand LIKE ? AND descripcion LIKE ? AND active = 'I'"; // Cambiamos la condición para registros inactivos
	        PreparedStatement pstm = cn.prepareStatement(sql);
	        pstm.setString(1, brand);
	        pstm.setString(2, descripcion);
	        ResultSet rs = pstm.executeQuery();
	        while (rs.next()) {
	            rec = new product();
	            rec.setId_product(rs.getInt("id_product"));
	            rec.setBrand(rs.getString("brand"));
	            rec.setDescripcion(rs.getString("descripcion"));
	            rec.setCategory(rs.getString("category"));
	            rec.setPrice(rs.getDouble("price"));
	            rec.setStock(rs.getInt("stock"));
	            rec.setActive(rs.getString("active").charAt(0));
	            lista.add(rec);
	        }
	        rs.close();
	        pstm.close();
	    } catch (SQLException e) {
	        throw new RuntimeException(e.getMessage());
	    } catch (Exception e) {
	        throw new RuntimeException("Error en el proceso");
	    } finally {
	        try {
	            cn.close();
	        } catch (Exception e) {
	        }
	    }
	    return lista;
	}

	@Override
	public void restore(Integer id) {
		// Variables
	    Connection cn = null;
	    PreparedStatement pstm = null;
	    String sql;

	    try {
	        // Inicio de la TX
	        cn = AccesoDB.getConnection();
	        cn.setAutoCommit(false);

	        // Realizar la restauración lógica marcando el registro como activo ('A')
	        sql = "UPDATE product SET active = 'A' WHERE id_product = ?";
	        pstm = cn.prepareStatement(sql);
	        pstm.setInt(1, id);

	        int rowsUpdated = pstm.executeUpdate();

	        if (rowsUpdated != 1) {
	            throw new RuntimeException("No se pudo realizar la restauración lógica del producto.");
	        }

	        // Fin de la TX
	        cn.commit();
	    } catch (SQLException e) {
	        try {
	            cn.rollback();
	        } catch (Exception e2) {
	        }
	        throw new RuntimeException("Error al realizar la restauración lógica del producto: " + e.getMessage());
	    } catch (Exception e) {
	        try {
	            cn.rollback();
	        } catch (Exception e2) {
	        }
	        throw new RuntimeException("Error en el proceso");
	    } finally {
	        try {
	            if (pstm != null) {
	                pstm.close();
	            }
	            if (cn != null) {
	                cn.close();
	            }
	        } catch (Exception e) {
	        }
	    }
	}

	@Override
	public String getCSVData() {
		// Lógica para obtener datos en formato CSV
        List<product> productos = getAll();
        StringBuilder csvData = new StringBuilder();
        csvData.append("ID,Marca,Descripción,Categoría,Precio,Stock\n");

        for (product producto : productos) {
            csvData.append(String.format("%d,%s,%s,%s,%.2f,%d\n",
                    producto.getId_product(),
                    producto.getBrand(),
                    producto.getDescripcion(),
                    producto.getCategory(),
                    producto.getPrice(),
                    producto.getStock()));
        }

        return csvData.toString();
    }


	@Override
	public HSSFWorkbook getXLSData() {
	    HSSFWorkbook workbook = new HSSFWorkbook(); // Inicializar el objeto HSSFWorkbook

	    HSSFSheet sheet = workbook.createSheet("Productos");

	    // Crear encabezados
	    HSSFRow headerRow = sheet.createRow(0);
	    headerRow.createCell(0).setCellValue("ID");
	    headerRow.createCell(1).setCellValue("Marca");
	    headerRow.createCell(2).setCellValue("Descripción");
	    headerRow.createCell(3).setCellValue("Categoría");
	    headerRow.createCell(4).setCellValue("Precio");
	    headerRow.createCell(5).setCellValue("Stock");

	    // Llenar los datos
	    int rowNum = 1;
	    List<product> productos = getAll(); // Obtener los productos
	    for (product producto : productos) {
	        HSSFRow row = sheet.createRow(rowNum++);
	        row.createCell(0).setCellValue(producto.getId_product());
	        row.createCell(1).setCellValue(producto.getBrand());
	        row.createCell(2).setCellValue(producto.getDescripcion());
	        row.createCell(3).setCellValue(producto.getCategory());
	        row.createCell(4).setCellValue(producto.getPrice());
	        row.createCell(5).setCellValue(producto.getStock());
	    }

	    return workbook;
	}

	@Override
	public void getPDFData(Document document) throws DocumentException {
	    // Obtener los datos para el informe (puedes usar tu lógica específica)
	    List<product> productos = getAll();

	    // Puedes personalizar el contenido según tus necesidades
	    for (product producto : productos) {
	        // Agregar información del producto al documento
	        document.add(new Paragraph("ID: " + producto.getId_product()));
	        document.add(new Paragraph("Marca: " + producto.getBrand()));
	        document.add(new Paragraph("Descripción: " + producto.getDescripcion()));
	        document.add(new Paragraph("Categoría: " + producto.getCategory()));
	        document.add(new Paragraph("Precio: " + producto.getPrice()));
	        document.add(new Paragraph("Stock: " + producto.getStock()));
	        document.add(new Paragraph("Estado: " + producto.getActive()));
	        document.add(new Paragraph("")); // Agregar espacio entre productos
	    }
	}

	@Override
	public List<product> getInactiveProveedor() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<product> getInactiveProveedor(product bean) {
		// TODO Auto-generated method stub
		return null;
	}


	

	
}

