package edu.pe.vallegrande.maestro2.prueba;

import edu.pe.vallegrande.maestro2.db.service.imple.CrudProductService;
import edu.pe.vallegrande.maestro2.model.product;

public class Prueba03 {

	public static void main(String[] args) {
		try {
			//Datos de consulta
			product model = new product();
			model.setBrand("Puma");
			model.setDescripcion("Color blanco");
			model.setCategory("Zapatilla");
			model.setPrice(150.0);
			model.setStock(2);
			//Proceso
			CrudProductService service = new CrudProductService();
			model = service.insert(model);
			//Reporte
			System.out.println("Registro creado con id=" + model.getId_product());
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
