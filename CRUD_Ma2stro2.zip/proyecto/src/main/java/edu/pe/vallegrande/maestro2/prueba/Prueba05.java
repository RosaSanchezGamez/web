package edu.pe.vallegrande.maestro2.prueba;

import edu.pe.vallegrande.maestro2.db.service.imple.CrudSupplierService;

public class Prueba05 {

	public static void main(String[] args) {
		try {
            int supplierIdToDelete = 10; 

            CrudSupplierService productService = new CrudSupplierService();
            productService.delete(supplierIdToDelete);

            System.out.println("Producto con ID " + supplierIdToDelete + " eliminado exitosamente.");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}