package edu.pe.vallegrande.maestro2.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.pe.vallegrande.maestro2.db.service.imple.CrudProductService;
import edu.pe.vallegrande.maestro2.model.product;

@WebServlet({ "/UpdateProduct" })
public class UpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int Id = Integer.parseInt(request.getParameter("id"));
		String brand = request.getParameter("brand");
		String descripcion = request.getParameter("descripcion");
		String category = request.getParameter("category");
		double price = Double.parseDouble(request.getParameter("price"));
		int stock = Integer.parseInt(request.getParameter("stock"));
		
		product updatedProduct = new product();
	    updatedProduct.setId_product(Id);
	    updatedProduct.setBrand(brand);
	    updatedProduct.setDescripcion(descripcion);
	    updatedProduct.setCategory(category);
	    updatedProduct.setPrice(price);
	    updatedProduct.setStock(stock);
	    
	    CrudProductService productService = new CrudProductService();
	    productService.update(updatedProduct);
	    
	    response.sendRedirect("Listar");
	}

}
