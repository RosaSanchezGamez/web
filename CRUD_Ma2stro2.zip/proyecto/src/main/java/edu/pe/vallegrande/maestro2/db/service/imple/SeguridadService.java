package edu.pe.vallegrande.maestro2.db.service.imple;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import edu.pe.vallegrande.maestro2.db.AccesoDB;
import edu.pe.vallegrande.maestro2.db.service.spec.SeguridadServiceSpec;
import edu.pe.vallegrande.maestro2.model.empleado;

public class SeguridadService implements SeguridadServiceSpec<empleado> {

	@Override
	public empleado validar(String usuario, String clave) {

		Connection cn = null;
		empleado bean = null;

		try {
			cn = AccesoDB.getConnection();
			String sql = "SELECT emp_id, emp_apellido, emp_nombre, emp_direccion, ";
			sql += "emp_email, emp_usuario, '*****' emp_clave";
			sql += " from empleado where emp_usuario=? and emp_clave=? ";
			PreparedStatement pstm = cn.prepareStatement(sql);
			pstm.setString(1, usuario);
			pstm.setString(2, clave);
			ResultSet rs = pstm.executeQuery();
			if (rs.next()) {
				bean = new empleado();
				bean.setId(rs.getInt("emp_id"));
				bean.setApellido(rs.getString("emp_apellido"));
				bean.setNombre(rs.getString("emp_nombre"));
				bean.setDireccion(rs.getString("emp_direccion"));
				bean.setEmail(rs.getString("emp_email"));
				bean.setUsuario(rs.getString("emp_usuario"));
				bean.setClave(rs.getString("emp_clave"));
			}
			rs.close();
			pstm.close();
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				cn.close();
			} catch (Exception e) {
			}
		}
		return bean;
	}

	@Override
	public List<empleado> getAll() {
		List<empleado> lista = new ArrayList<>();
		Connection cn = null;
		empleado rec = null;
		try {
			cn = AccesoDB.getConnection();
			String sql = "select emp_id, emp_apellido, emp_nombre, emp_direccion, emp_email, emp_usuario, emp_clave, active from empleado where active = 'A'";
			PreparedStatement pstm = cn.prepareStatement(sql);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				rec = new empleado();
				rec.setId(rs.getInt("emp_id"));
				rec.setApellido(rs.getString("emp_apellido"));
				rec.setNombre(rs.getString("emp_nombre"));
				rec.setDireccion(rs.getString("emp_direccion"));
				rec.setEmail(rs.getString("emp_email"));
				rec.setUsuario(rs.getString("emp_usuario"));
				rec.setClave(rs.getString("emp_clave"));
				rec.setActive(rs.getString("active").charAt(0));
				lista.add(rec);
			}
			rs.close();
			pstm.close();
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				cn.close();
			} catch (Exception e) {
			}
		}
		return lista;
	}

	@Override
	public List<empleado> getInactiveEmpleado() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<empleado> get(empleado bean) {
		// Preparando datos
		String apellido = "%" + (bean.getApellido() != null ? bean.getApellido().trim() : "") + "%";
		String nombre = "%" + (bean.getNombre() != null ? bean.getNombre().trim() : "") + "%";
		List<empleado> lista = new ArrayList<>();
		Connection cn = null;
		empleado rec = null;
		// Proceso
		try {
			cn = AccesoDB.getConnection();
			String sql = "SELECT emp_id, emp_apellido, emp_nombre, emp_direccion, emp_email, emp_usuario, emp_clave, active FROM empleado ";
			sql += " WHERE emp_apellido LIKE ? AND emp_nombre LIKE ? AND active = 'A'";
			PreparedStatement pstm = cn.prepareStatement(sql);
			pstm.setString(1, apellido);
			pstm.setString(2, nombre);
			ResultSet rs = pstm.executeQuery();
			while (rs.next()) {
				rec = new empleado();
				rec.setId(rs.getInt("emp_id"));
				rec.setApellido(rs.getString("emp_apellido"));
				rec.setNombre(rs.getString("emp_nombre"));
				rec.setDireccion(rs.getString("emp_direccion"));
				rec.setEmail(rs.getString("emp_email"));
				rec.setUsuario(rs.getString("emp_usuario"));
				rec.setClave(rs.getString("emp_clave"));
				rec.setActive(rs.getString("active").charAt(0));
				lista.add(rec);
			}
			rs.close();
			pstm.close();
		} catch (SQLException e) {
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				cn.close();
			} catch (Exception e) {
			}
		}
		return lista;
	}

	@Override
	public empleado insert(empleado bean) {
		// Variables
		Connection cn = null;
		String sql = null;
		PreparedStatement pstm = null;
		ResultSet rs;
		Integer id = 0;
		// Proceso
		try {
			// Inicio de la TX
			cn = AccesoDB.getConnection();
			cn.setAutoCommit(false);
			// Insertar registro
			sql = "INSERT INTO empleado(emp_apellido, emp_nombre, emp_direccion, emp_email, emp_usuario, emp_clave) VALUES(?,?,?,?,?,?)";
			pstm = cn.prepareStatement(sql);
			pstm.setString(1, bean.getApellido());
			pstm.setString(2, bean.getNombre());
			pstm.setString(3, bean.getDireccion());
			pstm.setString(4, bean.getEmail());
			pstm.setString(5, bean.getUsuario());
			pstm.setString(6, bean.getClave());
			pstm.executeUpdate();
			// Obteniendo el id
			sql = "SELECT @@IDENTITY emp_id";
			pstm = cn.prepareStatement(sql);
			rs = pstm.executeQuery();
			rs.next();
			id = rs.getInt("emp_id");
			bean.setId(id);
			// Fin de la TX
			cn.commit();
		} catch (SQLException e) {
			try {
				cn.rollback();
			} catch (Exception e2) {
			}
			throw new RuntimeException(e.getMessage());
		} catch (Exception e) {
			try {
				cn.rollback();
			} catch (Exception e2) {
			}
			throw new RuntimeException("Error en el proceso");
		} finally {
			try {
				cn.close();
			} catch (Exception e) {
			}
		}

		// Reporte
		bean.setId(id);
		return bean;
	}
}