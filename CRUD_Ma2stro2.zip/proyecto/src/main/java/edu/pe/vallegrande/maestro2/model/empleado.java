package edu.pe.vallegrande.maestro2.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data @AllArgsConstructor @NoArgsConstructor

public class empleado {

	
	private Integer id;
	private String apellido;
	private String nombre;
	private String direccion;
	private String email;
	private String usuario;
	private String clave;
	private char active;
}
