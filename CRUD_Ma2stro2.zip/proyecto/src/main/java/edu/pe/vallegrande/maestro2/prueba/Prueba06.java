package edu.pe.vallegrande.maestro2.prueba;

import edu.pe.vallegrande.maestro2.db.service.imple.CrudProductService;
import edu.pe.vallegrande.maestro2.model.product;

public class Prueba06 {

	public static void main(String[] args) {
		try {
			// Datos del producto a actualizar (excepto el ID)
			product productToUpdate = new product();
			productToUpdate.setId_product(1); // Configura el ID del producto que deseas actualizar
			productToUpdate.setBrand("New Atletic");
			productToUpdate.setDescripcion("Color azul");
			productToUpdate.setCategory("Zapatilla");
			productToUpdate.setPrice(180.0);
			productToUpdate.setStock(2);

			// Servicio para actualizar el producto
			CrudProductService productService = new CrudProductService();

			// Actualizar el producto
			product updatedProduct = productService.update(productToUpdate);

			if (updatedProduct != null) {
				// La actualización fue exitosa
				System.out.println("Producto actualizado con ID: " + updatedProduct.getId_product());
			} else {
				// Manejar un escenario de error si es necesario
				System.out.println("No se pudo actualizar el producto.");
			}
		} catch (Exception e) {
			// Manejar excepciones
			System.err.println("Error: " + e.getMessage());
		}
	}
}