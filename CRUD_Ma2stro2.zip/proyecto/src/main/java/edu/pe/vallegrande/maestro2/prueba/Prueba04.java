package edu.pe.vallegrande.maestro2.prueba;

import edu.pe.vallegrande.maestro2.db.service.imple.CrudProductService;
import edu.pe.vallegrande.maestro2.model.product;

public class Prueba04 {

	public static void main(String[] args) {
		try {
            int productIdToRead = 1;
            
            CrudProductService service = new CrudProductService();
            
            product model = service.read(productIdToRead);

            if (model != null) {
                System.out.println("Producto encontrado:");
                System.out.println("ID: " + model.getId_product());
                System.out.println("Marca: " + model.getBrand());
                System.out.println("Descripción: " + model.getDescripcion());
                System.out.println("Categoría: " + model.getCategory());
                System.out.println("Precio: " + model.getPrice());
                System.out.println("Stock: " + model.getStock());
            } else {
                System.out.println("No se encontró ningún producto con el ID: " + productIdToRead);
            }
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }
}
