package edu.pe.vallegrande.maestro2.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.pe.vallegrande.maestro2.db.service.imple.SeguridadService;
import edu.pe.vallegrande.maestro2.db.service.spec.SeguridadServiceSpec;
import edu.pe.vallegrande.maestro2.model.empleado;

@WebServlet({ "/InicioSesion", "/CerrarSesion" })
public class SecurityController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		switch (path) {
		case "/CerrarSesion":
			cerrarSesion(request, response);
			break;
		}
	}

	private void cerrarSesion(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getSession().invalidate();
		String destino = "index.jsp";
		// forward
		RequestDispatcher rd = request.getRequestDispatcher(destino);
		rd.forward(request, response);

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		switch (path) {
		case "/InicioSesion":
			inicioSesion(request, response);
			break;
		}
	}

	private void inicioSesion(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Variables
		String destino, usuario, clave;
		empleado empleado;
		try {
			// Datos
			usuario = request.getParameter("usuario");
			clave = request.getParameter("clave");
			// Proceso
			SeguridadServiceSpec<empleado> seguridad = new SeguridadService();
			empleado = seguridad.validar(usuario, clave);
			if (empleado == null) {
				request.setAttribute("error", "usuario o clave incorrectos :(");
				destino = "index.jsp";
			} else {
				request.getSession().setAttribute("usuario", empleado);
				destino = "home.jsp";
			}
		} catch (Exception e) {
			request.setAttribute("error", e.getMessage());
			destino = "index.jsp";
		}
		// forward
		RequestDispatcher rd = request.getRequestDispatcher(destino);
		rd.forward(request, response);
	}

}
