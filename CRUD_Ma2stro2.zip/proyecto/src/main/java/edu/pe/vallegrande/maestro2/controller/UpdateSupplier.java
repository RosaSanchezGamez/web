package edu.pe.vallegrande.maestro2.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.pe.vallegrande.maestro2.db.service.imple.CrudSupplierService;
import edu.pe.vallegrande.maestro2.model.supplier;

@WebServlet({ "/UpdateSupplier" })
public class UpdateSupplier extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		int Id = Integer.parseInt(request.getParameter("id"));
		String ruc = request.getParameter("ruc");
		String business_name = request.getParameter("business_name");
		String addres = request.getParameter("addres");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");
		
		supplier updatedSupplier = new supplier();
		updatedSupplier.setId_supplier(Id);
		updatedSupplier.setRuc(ruc);
		updatedSupplier.setBusiness_name(business_name);
		updatedSupplier.setAddres(addres);
		updatedSupplier.setEmail(email);
		updatedSupplier.setPhone(phone);
	    
	    CrudSupplierService supplierService = new CrudSupplierService();
	    supplierService.update(updatedSupplier);
	    
	    response.sendRedirect("ListSupplier");
	}

}
