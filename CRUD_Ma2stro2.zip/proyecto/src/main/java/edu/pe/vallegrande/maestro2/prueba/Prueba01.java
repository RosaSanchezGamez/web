package edu.pe.vallegrande.maestro2.prueba;

import java.util.List;

import edu.pe.vallegrande.maestro2.db.service.imple.CrudProductService;
import edu.pe.vallegrande.maestro2.model.product;

public class Prueba01 {
	
	public static void main(String[] args) {
		try {
			CrudProductService service = new CrudProductService();
			List<product> lista = service.getAll();

			System.out.println("Registros con active = 'I':");
			for (product rec : lista) {
				if (rec.getActive() == 'I') {
					System.out.println(rec.getId_product() + " - " + rec.getBrand() + " - " + rec.getDescripcion() + " - " + rec.getCategory() + " - " + rec.getPrice() + " - " + rec.getStock() + " - " + rec.getActive());
				}
			}
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
