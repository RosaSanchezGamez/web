package edu.pe.vallegrande.maestro2.prueba;

import java.util.List;

import edu.pe.vallegrande.maestro2.db.service.imple.SeguridadService;
import edu.pe.vallegrande.maestro2.model.empleado;

public class Prueba02 {
	
	public static void main(String[] args) {
		try {
			//Datos de consulta
			empleado model = new empleado();
			model.setApellido("Pa");
			model.setNombre("Se");
			//Proceso
			SeguridadService service = new SeguridadService();
			List<empleado> lista = service.get(model);
			//Reporte
			System.out.println("LISTADO");
			System.out.println("Registros: "+ lista.size());
			for(empleado rec : lista) {
				System.out.println(rec.getId() + " - " + rec.getApellido() + " - " + rec.getNombre());
			}
		}catch(Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
