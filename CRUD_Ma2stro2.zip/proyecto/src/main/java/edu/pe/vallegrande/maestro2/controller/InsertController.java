package edu.pe.vallegrande.maestro2.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import edu.pe.vallegrande.maestro2.db.service.imple.CrudProductService;
import edu.pe.vallegrande.maestro2.db.service.imple.CrudSupplierService;
import edu.pe.vallegrande.maestro2.model.product;
import edu.pe.vallegrande.maestro2.model.supplier;

@WebServlet({ "/InsertProduct", "/InsertSupplier", })
public class InsertController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String path = request.getServletPath();
		switch (path) {
		case "/InsertProduct":
			insertProduct(request, response);
			break;
		case "/InsertSupplier":
			insertSupplier(request, response);
			break;
		}

	}

	private void insertSupplier(HttpServletRequest request, HttpServletResponse response) throws IOException {
		String ruc = request.getParameter("ruc");
		String business_name = request.getParameter("business_name");
		String addres = request.getParameter("addres");
		String email = request.getParameter("email");
		String phone = request.getParameter("phone");

		supplier newSupplier = new supplier();
		newSupplier.setRuc(ruc);
		newSupplier.setBusiness_name(business_name);
		newSupplier.setAddres(addres);
		newSupplier.setEmail(email);
		newSupplier.setPhone(phone);

		CrudSupplierService service = new CrudSupplierService();
		service.insert(newSupplier);

		response.sendRedirect("ListSupplier");

	}

	private void insertProduct(HttpServletRequest request, HttpServletResponse response) throws IOException {

		String brand = request.getParameter("brand");
		String descripcion = request.getParameter("descripcion");
		String category = request.getParameter("category");
		double price = Double.parseDouble(request.getParameter("price"));
		int stock = Integer.parseInt(request.getParameter("stock"));

		product newProduct = new product();
		newProduct.setBrand(brand);
		newProduct.setDescripcion(descripcion);
		newProduct.setCategory(category);
		newProduct.setPrice(price);
		newProduct.setStock(stock);

		CrudProductService service = new CrudProductService();
		service.insert(newProduct);
		
		response.sendRedirect("Listar");
	}

}
