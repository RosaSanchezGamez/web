package edu.pe.vallegrande.maestro2.db.service.spec;

import java.util.List;

import edu.pe.vallegrande.maestro2.model.empleado;

public interface SeguridadServiceSpec <T> {
    
	
	/**
	 * 
	 * @param usuario El usuario del empleado
	 * @param clave   La clave del usuario
	 * @return        Retorna un objeto con los datos del empleado o un null si los datos no son correctos  
	 */
	empleado validar (String usuario, String clave);
	
	/**
	 * Consulta todos los usuarios de la tabla
	 * @return Retorna una lista de objetos
	 */
	List<T> getAll();
	
	/**
	 * Consulta todos los usuarios inactivos de la tabla
	 * @return Retorna una lista de objetos
	 */
	List<T> getInactiveEmpleado();
	
	/**
	 * Consulta registros en base a un filtro
	 * @param bean
	 * @return
	 */
	List<T> get (T bean);
	
	/**
	 * Este metodo se utiliza para insertar un nuevo registro en una BD
	 * @param bean 
	 * @return
	 */
	T insert(T bean);
}
