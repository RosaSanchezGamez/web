package edu.pe.vallegrande.maestro2.prueba;

import edu.pe.vallegrande.maestro2.db.service.imple.SeguridadService;
import edu.pe.vallegrande.maestro2.db.service.spec.SeguridadServiceSpec;
import edu.pe.vallegrande.maestro2.model.empleado;

public class Prueba07 {

	public static void main(String[] args) {
		try {
			// Datos de consulta
			String usuario = "sebaspad";
			String clave = "136266";
			// Proceso
			SeguridadServiceSpec<empleado> service = new SeguridadService();
			empleado bean = service.validar(usuario, clave);
			String reporte = "Datos incorrectos";
			if (bean != null) {
				reporte = "Datos correctos. Hola " + bean.getNombre() + ".";
			}
			// Reporte
			System.out.print(reporte);
		} catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}
}
